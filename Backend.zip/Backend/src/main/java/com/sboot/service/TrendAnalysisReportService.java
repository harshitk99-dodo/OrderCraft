package com.sboot.service;

import com.sboot.entity.InventoryTransaction;
import com.sboot.entity.PurchaseOrder;
import com.sboot.repository.InventoryTransactionRepository;
import com.sboot.repository.PurchaseOrdersRepository;
import org.springframework.stereotype.Service;

import java.time.*;
import java.util.*;

@Service
public class TrendAnalysisReportService {

    private final InventoryTransactionRepository inventoryRepo;
    private final PurchaseOrdersRepository purchaseOrderRepo;

    public TrendAnalysisReportService(InventoryTransactionRepository inventoryRepo,
                                      PurchaseOrdersRepository purchaseOrderRepo) {
        this.inventoryRepo = inventoryRepo;
        this.purchaseOrderRepo = purchaseOrderRepo;
    }

    public Map<String, Object> generateTrendReport(String metric, String start, String end) {

        Map<String, Object> response = new HashMap<>();
        List<Map<String, Object>> trend = new ArrayList<>();

        LocalDate startDate = LocalDate.parse(start);
        LocalDate endDate = LocalDate.parse(end);

        /* ---------------- STOCK USAGE TREND ---------------- */
        if ("stock-usage".equalsIgnoreCase(metric)) {

            List<InventoryTransaction> transactions =
                    inventoryRepo.findByDateRange(startDate, endDate);

            Map<LocalDate, Integer> dailyUsage = new TreeMap<>();

            for (InventoryTransaction tx : transactions) {

                if (tx.getItTransactionDate() == null || tx.getItQuantity() == null) continue;

                LocalDate date = tx.getItTransactionDate()
                        .toInstant()
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate();

                dailyUsage.put(date,
                        dailyUsage.getOrDefault(date, 0) + tx.getItQuantity());
            }

            dailyUsage.forEach((date, value) -> {
                Map<String, Object> point = new HashMap<>();
                point.put("date", date.toString());
                point.put("value", value);
                trend.add(point);
            });

            response.put("metric", "stock-usage");
        }

        /* ---------------- SUPPLIER PERFORMANCE TREND ---------------- */
        if ("supplier-performance".equalsIgnoreCase(metric)) {

            List<PurchaseOrder> orders =
                    purchaseOrderRepo.findByDateRange(
                            startDate.atStartOfDay(),
                            endDate.atTime(23, 59));

            Map<LocalDate, Integer> dailyOrders = new TreeMap<>();

            for (PurchaseOrder po : orders) {

                if (po.getPoOrderDate() == null) continue;

                LocalDate date = po.getPoOrderDate().toLocalDate();

                dailyOrders.put(date,
                        dailyOrders.getOrDefault(date, 0) + 1);
            }

            dailyOrders.forEach((date, value) -> {
                Map<String, Object> point = new HashMap<>();
                point.put("date", date.toString());
                point.put("value", value);
                trend.add(point);
            });

            response.put("metric", "supplier-performance");
        }

        response.put("success", true);
        response.put("trend", trend);

        return response;
    }
}
