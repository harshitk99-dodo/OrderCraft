package com.sboot.controller;

import com.sboot.service.ProductionEfficiencyReportService;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/productionefficiencyreports")
@CrossOrigin(origins = "*")
public class ProductionEfficiencyReportController {

    private final ProductionEfficiencyReportService reportService;

    public ProductionEfficiencyReportController(ProductionEfficiencyReportService reportService) {
        this.reportService = reportService;
    }

    // 🔹 Single unit OR all units
    @GetMapping("/efficiency")
    public Map<String, Object> generateReport(
            @RequestParam(required = false) Long unitId,

            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate startDate,

            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate endDate) {

        return reportService.generateEfficiencyReport(unitId, startDate, endDate);
    }

    // 🔹 All production units
    @GetMapping("/efficiency/all")
    public List<Map<String, Object>> generateAllUnitsReport(

            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate startDate,

            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate endDate) {

        return reportService.generateAllUnitsReport(startDate, endDate);
    }
}
