package com.sboot.controller;

public class NotificationController {

}
